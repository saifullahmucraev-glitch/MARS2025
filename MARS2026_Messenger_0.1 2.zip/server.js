const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const MESSAGES_FILE = path.join(DATA_DIR, "messages.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
for (const file of [USERS_FILE, MESSAGES_FILE]) {
  if (!fs.existsSync(file)) fs.writeFileSync(file, "[]", "utf8");
}
const read = file => { try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return []; } };
const write = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2), "utf8");
const safeUser = u => ({ id: u.id, username: u.username, email: u.email, createdAt: u.createdAt });

app.use(express.json({ limit: "1mb" }));
app.use(session({
  secret: process.env.SESSION_SECRET || "mars-dev-secret-change-before-deploying",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7 * 86400000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function loggedIn(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Сначала войдите в Mars." });
  next();
}

app.get("/api/health", (_req, res) => res.json({ name: "Mars", status: "online", version: "0.1.0" }));
app.get("/api/me", (req, res) => {
  const u = read(USERS_FILE).find(x => x.id === req.session.userId);
  res.json({ user: u ? safeUser(u) : null });
});

app.post("/api/register", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (username.length < 2 || username.length > 24) return res.status(400).json({ error: "Имя должно быть от 2 до 24 символов." });
  if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) return res.status(400).json({ error: "Введите правильный email." });
  if (password.length < 8) return res.status(400).json({ error: "Пароль должен содержать минимум 8 символов." });
  const users = read(USERS_FILE);
  if (users.some(u => u.email === email)) return res.status(409).json({ error: "Этот email уже зарегистрирован." });
  const user = { id: crypto.randomUUID(), username, email, passwordHash: await bcrypt.hash(password, 12), createdAt: new Date().toISOString() };
  users.push(user); write(USERS_FILE, users);
  req.session.userId = user.id;
  res.status(201).json({ user: safeUser(user), message: "Аккаунт создан. Проверка email пока не подключена." });
});

app.post("/api/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = read(USERS_FILE).find(u => u.email === email);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error: "Неверный email или пароль." });
  req.session.userId = user.id;
  res.json({ user: safeUser(user), message: "Вы вошли в Mars." });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ message: "Вы вышли." })));

app.get("/api/users", loggedIn, (req, res) => {
  const q = String(req.query.q || "").trim().toLowerCase();
  if (!q) return res.json({ users: [] });
  const users = read(USERS_FILE).filter(u => u.id !== req.session.userId && (u.username.toLowerCase().includes(q) || u.email.includes(q))).slice(0, 30).map(safeUser);
  res.json({ users });
});
app.get("/api/messages/:userId", loggedIn, (req, res) => {
  const messages = read(MESSAGES_FILE).filter(m =>
    (m.fromId === req.session.userId && m.toId === req.params.userId) ||
    (m.toId === req.session.userId && m.fromId === req.params.userId)
  );
  res.json({ messages });
});
app.post("/api/messages/:userId", loggedIn, (req, res) => {
  const text = String(req.body.text || "").trim();
  if (!text || text.length > 2000) return res.status(400).json({ error: "Сообщение должно быть от 1 до 2000 символов." });
  if (!read(USERS_FILE).some(u => u.id === req.params.userId)) return res.status(404).json({ error: "Пользователь не найден." });
  const messages = read(MESSAGES_FILE);
  const message = { id: crypto.randomUUID(), fromId: req.session.userId, toId: req.params.userId, text, createdAt: new Date().toISOString() };
  messages.push(message); write(MESSAGES_FILE, messages);
  res.status(201).json({ message });
});

app.listen(PORT, "0.0.0.0", () => console.log(`Mars 0.1 is running on port ${PORT}`));
