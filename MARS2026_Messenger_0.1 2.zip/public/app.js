const $ = id => document.getElementById(id);
let mode = "register", me = null, peer = null, timer;
document.querySelectorAll(".tab").forEach(b => b.addEventListener("click", () => {
  mode = b.dataset.mode;
  document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", x === b));
  $("nameLabel").classList.toggle("hidden", mode === "login");
  $("username").required = mode === "register";
  $("authSubmit").textContent = mode === "register" ? "Создать аккаунт" : "Войти";
  $("password").autocomplete = mode === "register" ? "new-password" : "current-password";
  $("authMsg").textContent = "";
}));
async function api(url, options={}) {
  const res = await fetch(url, {credentials:"same-origin", headers:{"Content-Type":"application/json"}, ...options});
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Произошла ошибка.");
  return data;
}
$("authForm").addEventListener("submit", async e => {
  e.preventDefault(); $("authMsg").textContent = "Подключаемся…";
  const body = {username:$("username").value, email:$("email").value, password:$("password").value};
  try {
    const d = await api(mode === "register" ? "/api/register" : "/api/login", {method:"POST", body:JSON.stringify(body)});
    me = d.user; showMessenger(); $("authMsg").textContent = d.message || "";
  } catch(err) { $("authMsg").textContent = err.message; }
});
function showMessenger() {
  $("auth").classList.add("hidden"); $("messenger").classList.remove("hidden");
  $("welcome").textContent = "Привет, " + me.username + "!";
}
$("logout").addEventListener("click", async () => {
  try { await api("/api/logout", {method:"POST",body:"{}"}); } catch {}
  me=null;peer=null;$("messenger").classList.add("hidden");$("auth").classList.remove("hidden");$("chat").classList.add("hidden");
});
$("search").addEventListener("input", () => { clearTimeout(timer); timer=setTimeout(searchUsers,250); });
async function searchUsers() {
  const q=$("search").value.trim();
  if(!q){$("users").innerHTML='<p class="note">Введи имя или email для поиска.</p>';return;}
  try {
    const d=await api("/api/users?q="+encodeURIComponent(q)); $("users").replaceChildren();
    if(!d.users.length){$("users").innerHTML='<p class="note">Пользователей не найдено. Для теста создай второй аккаунт в другом браузере.</p>';return;}
    d.users.forEach(u=>{const b=document.createElement("button");b.className="user";const strong=document.createElement("strong");strong.textContent=u.username;const small=document.createElement("small");small.textContent=u.email;b.append(strong,small);b.onclick=()=>openChat(u);$("users").append(b);});
  } catch(err){$("appMsg").textContent=err.message;}
}
async function openChat(u){peer=u;$("chat").classList.remove("hidden");$("chatTitle").textContent="Чат с "+u.username;await refreshMessages();}
async function refreshMessages(){
  if(!peer)return;
  try {
    const d=await api("/api/messages/"+peer.id), box=$("messages");box.replaceChildren();
    d.messages.forEach(m=>{const bubble=document.createElement("div");bubble.className="bubble"+(m.fromId===me.id?" mine":"");const txt=document.createElement("div");txt.textContent=m.text;const time=document.createElement("time");time.textContent=new Date(m.createdAt).toLocaleString();bubble.append(txt,time);box.append(bubble);});
    box.scrollTop=box.scrollHeight;
  } catch(err){$("appMsg").textContent=err.message;}
}
$("sendForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!peer)return;const input=$("messageText"),text=input.value.trim();if(!text)return;
  try{await api("/api/messages/"+peer.id,{method:"POST",body:JSON.stringify({text})});input.value="";await refreshMessages();}catch(err){$("appMsg").textContent=err.message;}
});
(async()=>{try{const d=await api("/api/me");if(d.user){me=d.user;showMessenger();}}catch{}})();
